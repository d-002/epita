/////////////////////////
// TOGGLE OPTIONS HERE //
/////////////////////////
const useDarkTheme = true;
const betterCards = true;
const removeCookiePopup = true;
/////////////////////////

function removeAccents(word) {
    return word.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function sanitizeTitle(raw) {
    const keywords = [raw];
    let sanitized = raw;

    for (let year = new Date().getFullYear(), i = 0; i < 5; i++) {
        const find = (year + i).toString();
        if (!sanitized.includes(find))
            continue;

        keywords.push(year);
        sanitized = sanitized.replaceAll(find, "");
    }
    sanitized = sanitized.replaceAll("_", " ").trim();

    sanitized.split(" ").forEach(word => {
        if (word.length && !keywords.includes(word) && word != "-" && word != ":")
            keywords.push(removeAccents(word));
    });

    return [sanitized, keywords];
}

function matches(query, card) {
    query = removeAccents(query.toLowerCase().trim());
    if (query.length == 0)
        return 1;

    // title match
    const title = removeAccents(card.title.toLowerCase());
    if (title.includes(query))
        return query.length / title.length;

    // keywords match
    let result = 0;
    card.keywords.forEach(keyword => {
        if (query.includes(keyword))
            result += keyword.length / query.length;
    });

    return result / card.keywords.length;
}

function cards() {
    const cards = []; // list of { sanitized title, keywords, image, link, elt }

    const parent = document.querySelector(".paged-content-page-container>div>div");
    if (parent == null)
        return;

    Array.from(parent.children).forEach((card) => {
        let title, image, link;
        try {
            title = card.children[0].children[0].children[0].children[0].innerHTML;
            image = card.children[0].children[0].children[0].style.backgroundImage.trim();
            image = image.substring(5, image.length - 2);
            link = card.children[0].children[0].href;
        } catch {
            return;
        }

        const [sanitized, keywords] = sanitizeTitle(title);
        cards.push({ title: sanitized, keywords: keywords, image: image, link: link, elt: null });
    });

    const ok = Object.keys(cards).length > 5;
    if (!ok && Date.now()-startTime > 10000) {
        console.log("Moodle enhancements: Slow network detected, aborted changing cards.");
        self.clearInterval(cardsInterval);
        return;
    }

    if (!ok)
        return;

    self.clearInterval(cardsInterval);

    parent.innerHTML = "";
    parent.className = "custom-cards-container";

    function updateSearch(query) {
        const matching = []; // list of (card, score) tuples
        const matchingCards = [];

        cards.forEach(card => {
            const score = matches(query, card);
            if (!score)
                return;

            matching.push([card, score]);
            matchingCards.push(card);
        });

        matching.sort((a, b) => a.score - b.score).forEach(([card, _]) => {
            if (card.elt != null)
                return;

            const block = document.createElement("A");
            block.href = card.link;
            block.innerHTML = '<img src="' + card.image + '"><p>' + card.title + "</p>";
            parent.appendChild(block);
            card.elt = block;
        });

        cards.forEach(card => {
            if (matchingCards.includes(card))
                return;
            if (card.elt == null)
                return;
            card.elt.remove();
            card.elt = null;
        });
    }
    updateSearch("");

    // update search bar
    const bar = parent.parentNode.parentNode.parentNode.parentNode.parentNode.previousElementSibling;
    bar.innerHTML = '<input type="text" class="form-control withclear rounded" placeholder="Rechercher" id="qsdfmlkjqsdmlkj">';
    const input = document.getElementById("qsdfmlkjqsdmlkj");
    input.focus();
    input.addEventListener("input", () => updateSearch(input.value));
}

function getMainStyle() {
    let style;
    Array.from(document.getElementsByTagName("link")).forEach(elt => {
        if (elt.getAttribute("rel") != "stylesheet") return;
        if (elt.href.includes("styles.php")) style = elt;
    });

    return style;
}

function editCss() {
    if (useDarkTheme) {
        let cached = localStorage.getItem("cachedDarkTheme");
        let time = localStorage.getItem("cachedDarkThemeTime") | 0;
        if (Date.now() - time > 1000 * 86400 * 30)
            cached = null; // cache is invalidated after 30 days
        if (cached == null) {
            console.log("Baking dark theme css");
            cached = bakeCss();
            localStorage.setItem("cachedDarkTheme", cached);
            localStorage.setItem("cachedDarkThemeTime", Date.now());
        }
        const darkCss = document.createElement("STYLE");
        darkCss.innerHTML = cached;

        document.head.appendChild(darkCss);
        self.setTimeout(() => tempDarkCss.remove(), 100);
    }
    document.head.appendChild(customCss);
}

// dark theme
const customCss = document.createElement("STYLE");

customCss.innerHTML += `
.custom-cards-container {
    display: flex;
    justify-content: space-between;
    gap: .5em;
    flex-wrap: wrap;
}

.custom-cards-container a {
    display: flex;
    align-items: center;
    gap: .5em;

    width: 250px;
    height: 100px;
    padding: .5em;

    border: 1px solid #8885;
    border-radius: .5em;
    background-color: #fff1;
}

.custom-cards-container img {
    max-width: 100px;
    max-height: 100%;
    border-radius: .5em;
}

.custom-cards-container p {
    margin: 0;
}`;

if (useDarkTheme)
    customCss.innerHTML += `
/* dark theme fixes */
    .modal-backdrop {
        background-color: #000;
    }

    tr:nth-of-type(even) {
        background-color: #333 !important;
    }

    .pagelayout-login #page {
        background-image: linear-gradient(to right, #23262b 0%, #373d45 100%);
    }
`;

const tempDarkCss = document.createElement("STYLE");
tempDarkCss.innerHTML = `
    :is(*, .bg-white):not(.newcard *) {
        color: #ccc !important;
        background-color: #303236 !important;
        transition-duration: 1s;
    }`;
if (useDarkTheme)
    document.documentElement.appendChild(tempDarkCss);

const startInterval = self.setInterval(() => {
    if (getMainStyle() != null) {
        editCss();
        self.clearInterval(startInterval);
    }
}, 50);

const cookie_timeout = 10; // seconds
const cookies_texts = [
    "nous stockons des informations fonctionnelles dans votre navigateur",
    "we store functional information in your browser"
];

function cookies() {
    const popup = document.querySelector("div.modal.moodle-has-zindex.show > div.modal-dialog.modal-dialog-scrollable");
    if (popup == null) {
        if (Date.now() - startTime > cookie_timeout * 1000) {
            console.log("Cookie destroyer timed out from slow connection, will not try to remove popup.");
            self.clearInterval(interval_cookies);
        }
        return;
    }

    const text = popup.children[0].children[1].children[0].innerHTML;
    let is_cookie = false;
    cookies_texts.forEach(t => is_cookie |= text.includes(t));

    if (is_cookie) {
        popup.parentNode.remove();
        document.querySelector("div.modal-backdrop.in.show").remove();
        self.clearInterval(interval_cookies);
    }
}

let startTime;
let cardsInterval;

self.addEventListener("load", () => {
    startTime = Date.now()

    let href = document.location.href;
    if (href.endsWith("/")) href = href.substring(0, href.length-1);
    if (href.endsWith("/index.php")) href = href.substring(0, href.length-10);
    if (href.endsWith("my")) {
        // main page
        if (betterCards)
            cardsInterval = self.setInterval(cards, 100);
    }

    if (removeCookiePopup)
        interval_cookies = self.setInterval(cookies, 100);
});

/// CSS baking

function toCol(i, expand) {
    const c = i.toString(16);
    if (expand)
        return c.length == 1 ? "0"+c : c;
    return c.length == 1 ? c : c[0];
}

function smartInvert(col) {
    let r, g, b, a = 255;
    const expand = col.length >= 7;
    if (expand) {
        r = parseInt(col.substring(1, 3), 16);
        g = parseInt(col.substring(3, 5), 16);
        b = parseInt(col.substring(5, 7), 16);
        if (col.length > 7) a = parseInt(col.substring(7, 9), 16);
    }
    else {
        r = parseInt(col[1], 16)*17;
        g = parseInt(col[2], 16)*17;
        b = parseInt(col[3], 16)*17;
        if (col.length > 4) a = parseInt(col[4], 16)*17;
    }

    const min = Math.max(Math.min(r, g, b)-30, 0);
    const span = Math.max(r, g, b)-min;
    const add = 255-span-2*min;
    [r, g, b] = [Math.min(r+add+0, 255), Math.min(g+add+2, 255), Math.min(b+add+6, 255)];

    return "#"+toCol(r, expand)+toCol(g, expand)+toCol(b, expand)+toCol(a, expand);
}

function smartInvertRgba(rgba) {
    let s = rgba.substring(rgba.indexOf("(")+1);
        s = s.substring(0, s.length-1).split(",");
        const r = parseInt(s[0]);
        const g = parseInt(s[1]);
        const b = parseInt(s[2]);
        const a = s.length == 4 ? parseInt(Number(s[3])*255) : 255;

        return smartInvert("#"+toCol(r, 1)+toCol(g, 1)+toCol(b, 1)+toCol(a, 1));
    }

const colorRules = "backgroundColor borderColor color scrollbarColor".split(" ");
const colorRulesCss = "background-color border-color color scrollbar-color".split(" ");

function smartInvertStyle(rules) {
    let text = "";

    const I = colorRules.length;
    rules.forEach(rule => {
        if (!rule.style) return;
        const useful = [];

        const isImportant = rule.cssText.includes("!important");

        for (let i = 0; i < I; i++) {
            const value = rule.style[colorRules[i]];
            if (value) {
                const ruleCss = colorRulesCss[i];

                // I hope there aren't any gradients
                const important = isImportant ? " !important" : "";

                const inverted = value[0] == "#" ? smartInvert(value.split(" ")[0]) : value.startsWith("rgb") ? smartInvertRgba(value) : null;
                if (inverted) useful.push(ruleCss+":"+inverted+important);
            }
        }

        if (useful.length) text += rule.selectorText+"{"+useful.join(";")+"}";
    });

    return text;
}

function bakeCss() {
    // get the main style element
    const style = getMainStyle();

    const rules = Array.from(style.sheet.cssRules);
    return smartInvertStyle(rules);
}
